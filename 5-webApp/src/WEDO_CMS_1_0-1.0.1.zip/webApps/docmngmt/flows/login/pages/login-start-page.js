define([], () => {
  'use strict';

  class PageModule {
  }
  
  return PageModule;
});
