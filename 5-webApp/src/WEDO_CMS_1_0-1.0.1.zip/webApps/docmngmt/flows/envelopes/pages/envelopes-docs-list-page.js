define(['resources/js/base64'], (Base64) => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getExpedients(arg1) {

      return new Promise(function(resolve, reject) {
      
        let username = 'xxxxxxxx';
        let password = 'xxxxxxxx';

        let chaincode = "wedocms";
        let sync = true;
        let bcTimeout = 60000;	
        let args = [];
        
        let payload = {};
        payload.chaincode = chaincode;
        payload.args = args;
        //payload.args.push("retrieveDocuments", tokenId, dateTime, deposit, data3.id.toString());
        payload.args.push("retrieveDocuments", arg1);
        payload.sync = sync;
        payload.timeout = bcTimeout;
        
        var options ={};
        options.method = 'POST';
        //options.url = 'https://org1-wedoinfra-fra.blockchain.ocp.oraclecloud.com:7443/restproxy/api/v2/channels/wedocms/transactions';
        options.url = 'https://org1-wedoinfra-fra.blockchain.ocp.oraclecloud.com:7443/restproxy/api/v2/channels/wedocms/chaincode-queries';
        //options.headers={
          //	"Content-Type": "application/json",
          //	"Authorization": "Basic " + Base64.encode(username + ":" + password)};
        options.body=JSON.stringify(payload);
        
        var settings = {
          "async": true,
          "crossDomain": true,
          "url": options.url,
          "method": "POST",
          "headers": {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Basic " + Base64.encode(username + ":" + password)},
          "processData": false,
          "error": (jqXHR, exception) => {
            if (jqXHR.status === 401) {
              console.error(jqXHR.responseText);
            } else {
              console.error('Uncaught Error.\n' + jqXHR.responseText);
            }
          },
          "data": options.body
        };

        $.ajax(settings).done(response => {
          if (response.returnCode == "Success") {
            console.log("*********");
            console.log(JSON.stringify(response));
            //const result = response;
            var response2 = {};
            response2.body = response;
            resolve(response2);
            //return result;
          }
        });
      });
    };
  }
  
  return PageModule;
});
