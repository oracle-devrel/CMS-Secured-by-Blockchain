define(['resources/js/crypto-js.min','resources/js/base64'], (CryptoJS,Base64) => {
  'use strict';

  class PageModule {


    showDialogDynamicProps(arg1) {
      document.querySelector('#dialogDynamicProps').open();
    }

    hideDialogDynamicProps(arg1) {
      document.querySelector('#dialogDynamicProps').close();
    }

    stringify(payload) {
      var reply = JSON.stringify(payload);
      return reply;
    }

    downloadFile(data, mimeType, filename) {

      const blob = new Blob([data], {
        type: mimeType
      });

      // IE/Edge
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob);
        return;
      }
      var link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      link.click();

      // Firefox: delay revoking the ObjectURL
      setTimeout(function() {
        URL.revokeObjectURL(blob);
      }, 100);
    }

    recalculateHash(data, mimeType, filename) {
      var readDataPromise = new Promise(function(resolve) {
        const blob = new Blob([data], {
          type: mimeType
        });

        const reader = new FileReader();
        reader.readAsDataURL(blob);

        reader.onload = () => {
          // The result is a Data URL, which contains the Base64 encoded content
          const base64Content = reader.result.split(',')[1];
          const base64 = base64Content.substr(base64Content.indexOf('base64')).substr(7);
          const hash = CryptoJS.SHA256(base64Content);
          resolve(hash + "");
        };

      });
      return readDataPromise;
    }

    getFileName(fileSet) {
      var fileName = fileSet.split(' (')[0];
      return fileName;
    }

    getFileType(fileSet) {
      var fileType = fileSet.split(' (')[1];
      fileType = fileType.substr(0, fileType.length - 1);
      return fileType;
    }

  }

  return PageModule;
});




