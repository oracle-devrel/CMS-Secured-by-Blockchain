define([], () => {
  'use strict';

  class PageModule {


    getNextExpedientID(expedientArray) {
      var nextExpSeq = expedientArray.length + 1;
      return "OP-EXP-" + nextExpSeq;
    }

    getCurrentDateTime(){
      var now = new Date();
      //var strDateTime = [[AddZero(now.getDate()), 
      //  AddZero(now.getMonth() + 1), 
      //  now.getFullYear()].join("/"), 
      //  [AddZero(now.getHours()), 
      //  AddZero(now.getMinutes())].join(":"), 
      //  now.getHours() >= 12 ? "PM" : "AM"].join(" ");
      //return "" + strDateTime;
      return now.toISOString();
    }

    stringify(payload) {
      var reply = JSON.stringify(payload);
      return reply;
    }
    
  }

  return PageModule;
});




