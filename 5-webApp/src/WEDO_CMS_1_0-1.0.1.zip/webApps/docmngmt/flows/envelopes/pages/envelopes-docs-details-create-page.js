define([], () => {
  'use strict';

  class PageModule {

    preparePayload2(method, args) {
      //method = method.charAt(0).toUpperCase() + method.slice(1);
      var arr2 = [];
      args.splice(0, 0, method)
      let payload = {
        "chaincode": "wedocmstmp",
        "sync": true,
        "args": args
      }
      return payload;
    }

    stringify(payload) {
      var reply = JSON.stringify(payload);
      return reply;
    }

    getFileName(fileSet) {
      var csvFile = fileSet[0];
      return csvFile.name;
    }

    getFileType(fileSet) {
      var csvFile = fileSet[0];
      return csvFile.type;
    }

    getFile(fileSet) {
      var csvFile = fileSet[0];
      return csvFile;
    }

    populatePropNameArray(propsArray) {
      var a = [];
      for (var i = 0; i < propsArray.length; i++) {
        a.push(propsArray[i].propName);
      }
      return JSON.stringify(a);
    }

    populatePropValueArray(propsArray) {
      var a = [];
      for (var i = 0; i < propsArray.length; i++) {
        a.push(propsArray[i].propValue);
      }
      return JSON.stringify(a);
    }

  }
  
  return PageModule;
});
