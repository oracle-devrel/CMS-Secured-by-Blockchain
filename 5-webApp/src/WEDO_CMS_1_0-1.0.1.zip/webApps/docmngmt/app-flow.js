define(['resources/js/crypto-js.min','resources/js/base64'], function(CryptoJS,Base64) {

  'use strict';

  var AppModule = function AppModule() {};

  AppModule.prototype.parseUploadedFile = function(fileSet) {
    var readDataPromise = new Promise(function(resolve) {
      if (fileSet.length > 0) {
        //Grab the first (and only) file
        var csvFile = fileSet[0];
        //Check it's the correct type
        if (csvFile.type === 'application/pdf') {
          //Create a File reader and its onload callback
          var fileReader = new FileReader();
          fileReader.onload = function(fileReadEvent) {
            var readCSVData = fileReadEvent.target.result;
            const base64 = readCSVData.substr(readCSVData.indexOf('base64')).substr(7);
            const hash = CryptoJS.SHA256(base64);
            resolve(hash);
          };
          //.readAsText
          fileReader.readAsDataURL(csvFile);
        }
      }
    });
    return readDataPromise;
  };

  AppModule.prototype.getHASH = function(data) {
    var readDataPromise = new Promise(function(resolve) {
      const base64 = data.substr(data.indexOf('base64')).substr(7);
      const hash = CryptoJS.SHA256(base64);
      resolve(hash);
    });
    return readDataPromise;
  };

  AppModule.prototype.scapedStr = function(args) {
    var reply1 = JSON.stringify(args);
    //var re = new RegExp('"', 'g');
    //reply1 = reply1.replace(re, '\\"');
    return reply1;
  };


  AppModule.prototype.preparePayload2 = function(method, args) {
    //method = method.charAt(0).toUpperCase() + method.slice(1);
    var arr2 = [];
    arr2[0] = method;
    arr2[1] = args;
    let payload = {
      "chaincode": "wedocmstmp",
      "sync": true,
      "args": arr2
    };

    return payload;
  };

  /**
   *
   * @param {String} endpoint
   * @param {String} username
   * @param {String} password
   * @param {String} channel
   * @param {String} chaincode
   * @param {String} method
   * @param {String} args
   * @return {String}
   */
  AppModule.prototype.bcQuery = function(endpoint, username, password, channel, chaincode, method, args) {

    return new Promise(function(resolve, reject) {
    
      //Method is the first argument in args[] array
      var args2 = [];
      args2[0] = method;
      for (var i = 0; i < args.length; i++) {
        args2.push(args[i]);
      }

      let payload = {};
      payload.chaincode = chaincode;
      payload.args = args2;
      payload.sync = true;
      payload.timeout = 60000;
      
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": endpoint + '/api/v2/channels/' + channel + '/chaincode-queries',
        "method": "POST",
        "headers": {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": "Basic " + Base64.encode(username + ":" + password)},
        "processData": false,
        "error": (jqXHR, exception) => {
          /*if (jqXHR.status === 401) {
            console.error(jqXHR.responseText);
          } else {
            console.error('Uncaught Error.\n' + jqXHR.responseText);
          }*/
        },
        "data": JSON.stringify(payload)
      };

      $.ajax(settings).done(response => {
        if (response.returnCode == "Success") {
          //console.log(JSON.stringify(response));
          var response2 = {};
          response2.body = response;
          resolve(response2);
        }
      });
    });
  };

  /**
   *
   * @param {String} endpoint
   * @param {String} username
   * @param {String} password
   * @param {String} channel
   * @param {String} chaincode
   * @param {String} method
   * @param {String} args
   * @return {String}
   */
  AppModule.prototype.bcTx = function(endpoint, username, password, channel, chaincode, method, args) {

    return new Promise(function(resolve, reject) {
    
      //Method is the first argument in args[] array
      var args2 = [];
      args2[0] = method;
      for (var i = 0; i < args.length; i++) {
        args2.push(args[i]);
      }

      let payload = {};
      payload.chaincode = chaincode;
      payload.args = args2;
      payload.sync = true;
      payload.timeout = 60000;
      
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": endpoint + '/api/v2/channels/' + channel + '/transactions',
        "method": "POST",
        "headers": {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": "Basic " + Base64.encode(username + ":" + password)},
        "processData": false,
        "error": (jqXHR, exception) => {
          /*if (jqXHR.status === 401) {
            console.error(jqXHR.responseText);
          } else {
            console.error('Uncaught Error.\n' + jqXHR.responseText);
          }*/
        },
        "data": JSON.stringify(payload)
      };

      $.ajax(settings).done(response => {
        if (response.returnCode == "Success") {
          //console.log(JSON.stringify(response));
          var response2 = {};
          response2.body = response;
          resolve(response2);
        }
      });
    });
  };



  

  return AppModule;
});
